package thaumcraft.api.golems.parts;

import thaumcraft.api.golems.IGolemAPI;

public interface IGenericFunction {
	void onUpdateTick(IGolemAPI golem);
}
