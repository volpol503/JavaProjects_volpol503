package thaumcraft.api.crafting;

public interface IThaumcraftRecipe  {
	String getResearch();
	String getGroup();
}
