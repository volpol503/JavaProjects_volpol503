///*------------------------------------------------------------------------------
// Copyright (c) CovertJaguar, 2011-2016
// http://railcraft.info
//
// This code is the property of CovertJaguar
// and may only be used with explicit written
// permission unless otherwise specified on the
// license page at http://railcraft.info/wiki/info:license.
// -----------------------------------------------------------------------------*/
//package mods.railcraft.common.plugins.thaumcraft;
//
//import mods.railcraft.common.items.ItemCrowbar;
//import mods.railcraft.common.items.ItemMaterials;
//import net.minecraftforge.fml.common.Optional;
//
///**
// * @author CovertJaguar <http://www.railcraft.info>
// */
//
//@Optional.Interface(iface = "thaumcraft.api.items.IRepairable", modid = "Thaumcraft")
//public class ItemCrowbarThaumium extends ItemCrowbar /*implements IRepairable*/ {
//    public ItemCrowbarThaumium() {
//        super(ItemMaterials.Material.THAUMIUM, ThaumcraftPlugin.getThaumiumToolMaterial());
//    }
//
//}
