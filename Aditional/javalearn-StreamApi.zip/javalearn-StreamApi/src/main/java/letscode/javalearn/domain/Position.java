package letscode.javalearn.domain;

public enum Position {
    MANAGER, WORKER, CHEF;
}
