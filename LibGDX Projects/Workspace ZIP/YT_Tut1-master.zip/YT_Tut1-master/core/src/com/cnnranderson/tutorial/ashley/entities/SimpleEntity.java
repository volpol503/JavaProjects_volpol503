package com.cnnranderson.tutorial.ashley.entities;

import com.badlogic.ashley.core.Entity;

public class SimpleEntity extends Entity {

}
