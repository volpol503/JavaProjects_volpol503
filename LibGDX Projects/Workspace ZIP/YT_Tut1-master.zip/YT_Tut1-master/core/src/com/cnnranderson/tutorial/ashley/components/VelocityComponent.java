package com.cnnranderson.tutorial.ashley.components;

import com.badlogic.ashley.core.Component;

public class VelocityComponent extends Component {
    public float dx = 0.0f;
    public float dy = 0.0f;
}
