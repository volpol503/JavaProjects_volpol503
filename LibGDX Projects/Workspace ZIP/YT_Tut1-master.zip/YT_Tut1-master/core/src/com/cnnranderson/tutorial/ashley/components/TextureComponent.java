package com.cnnranderson.tutorial.ashley.components;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.Texture;

public class TextureComponent extends Component {
    public Texture texture = null;
}
