package com.cnnranderson.tutorial.states;

import com.cnnranderson.tutorial.managers.GameStateManager;

public class TutAshleyState extends GameState {

    public TutAshleyState(GameStateManager gsm) {
        super(gsm);
    }

    @Override
    public void update(float delta) {

    }

    @Override
    public void render() {

    }

    @Override
    public void dispose() {

    }
}
